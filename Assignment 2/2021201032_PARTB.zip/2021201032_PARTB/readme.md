## SERC Website
Developed using HTML, CSS, Javascript, JQuery and Bootstrap.

Not implemented Admin mode and resources page.